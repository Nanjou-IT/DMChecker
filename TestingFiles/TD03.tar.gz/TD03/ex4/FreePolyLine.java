import java.util.LinkedList;
import java.util.ListIterator;

public class FreePolyLine {
	
	private LinkedList<Point> list;

	private int nbPoints;
	
	public FreePolyLine(){
		list = new LinkedList<Point>();
	}
	
	//@SuppressWarnings("unchecked")
	public void add( Point p ){
		list.add(p);
	}
	
	public int pointCount() {
		return this.list.size();
	}
	
	public boolean contains( Point p ) {
		
		return list.contains(p);
	}
	
	@Override
	public String toString(){
		String points = "";
		ListIterator<Point> itr = list.listIterator();

		while(itr.hasNext()){
			points += itr.next();
			if( itr.nextIndex() != list.size() ){
				points += ", ";
			}
		}
		
		return "["+points+"]";
	}
	
	public static void main( String[] args){
		
		FreePolyLine poly = new FreePolyLine();
		
		Point p1=new Point(1,2);
		Point p2=new Point(2,3);
		Point p3=new Point(3,4);
		Point p4=new Point(4,5);
		Point p5=new Point(5,6);
		
		poly.add(p1);
		poly.add(p2);
		poly.add(p3);
		poly.add(p4);
		//poly.add(p5);
		
		System.out.println("Nombre points alloués : " + poly.pointCount());
		
		System.out.println("PolyLine contient p1? : " + poly.contains(p1));
		System.out.println("PolyLine contient p5? : " + poly.contains(p5));
		
		//System.out.println("PolyLine contient p5? : " + poly.contains(null));
		//poly.add(null);
		
		System.out.println(poly);
	}
}



/** 
	Exercice 2 :
	
	1/ Même réponse :)

*/
