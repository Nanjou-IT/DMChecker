public class PolyLine {
	
	private Point tab[];

	private int nbPoints;
	private int cpt = 0;

	
	public PolyLine(int nbPoints){
		this.nbPoints = nbPoints;
		tab = new Point[nbPoints];
	}

	public PolyLine(){
		this(10); 	// permet la non duplication de code
	}
	
	public void add( Point p ){
		try {
			tab[this.cpt] = p;
			this.cpt += 1;
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Exception : Plus de place dans la PolyLine allouée.");
		}
	}
	
	public int pointCapacity() {
		return this.nbPoints;
	}
	
	public int pointCount() {
		return this.cpt;
	}
	
	public boolean contains( Point p ) {
		
		for (int i=0; i<this.cpt;i++){
			if ( tab[i].isSameAs(p) ) {
				return true;
			}
		}
		return false;
	}
	
	@Override
	public String toString(){
		String points = "";
		
		for(int i=0; i<this.cpt;i++){
			points += "("+tab[i].getX()+","+tab[i].getY()+")";
			if(i<(this.cpt-1)){
				points += ", ";
			}
		}
		
		return "[" + points + "]";
	}
	
	public static void main( String[] args){
		
		PolyLine poly = new PolyLine(5);
		System.out.println(poly);
		
		Point p0 = new Point();
		poly.add(p0);
		
		System.out.println(poly);

		Point p1 = new Point(1,1);
		poly.add(p1);
		
		System.out.println(poly);
		
	}
}


/**

Exercice 4 : 
	
	1/ Problème => multiplication des String dans la surcharge de toString.
		
	
*/
