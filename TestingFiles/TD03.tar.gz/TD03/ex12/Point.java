import java.util.ArrayList;

public class Point {
	public static int nbPoints;
	
	private int x;
	private int y;
	
	
	public Point(int x, int y){
		this.x = x;
		this.y = y;
		nbPoints+=1;
	}

	public Point(){
		this(0,0); 	// permet la non duplication de code
	}
	
	public Point(int x){
		this(x,x);
	}
	
	public Point( Point p1 ){
		this(p1.x,p1.y);
	}

	public int getX(){
		return this.x;
	}
	
	public int getY(){
		return this.y;
	}

	public static int totalCreated() {
		return nbPoints;
	}
	
	public boolean isSameAs( Point p2 ){
		return (this.x==p2.x && this.y==p2.y);
	}
	
	@Override
	public boolean equals( Object o ){
		if ( !(o instanceof Point) ){
			return false;
		}
		Point p = (Point)o;
		return this.isSameAs(p);
	}
	
	@Override
	public String toString(){
		return "("+this.x+","+this.y+")";	// chaine constante
	}
}



