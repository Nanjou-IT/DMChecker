import java.util.LinkedList;

public class FreePolyLine {
	
	private LinkedList<Point> list;

	private int nbPoints;
	private int cpt = 0;

	
	public FreePolyLine(){
		list = new LinkedList<Point>();
	}
	
	//@SuppressWarnings("unchecked")
	public void add( Point p ){
		list.add(p);
	}
	
	public int pointCount() {
		return this.list.size();
	}
	
	public boolean contains( Point p ) {
		
		return list.contains(p);
	}
	
	public static void main( String[] args){
		
		FreePolyLine poly = new FreePolyLine();
		
		Point p1=new Point(1,2);
		Point p2=new Point(2,3);
		Point p3=new Point(3,4);
		Point p4=new Point(4,5);
		Point p5=new Point(5,6);
		
		poly.add(p1);
		poly.add(p2);
		poly.add(p3);
		poly.add(p4);
		//poly.add(p5);
		
		System.out.println("Nombre points alloués : " + poly.pointCount());
		
		System.out.println("PolyLine contient p1? : " + poly.contains(p1));
		System.out.println("PolyLine contient p5? : " + poly.contains(p5));
		
		//System.out.println("PolyLine contient p5? : " + poly.contains(null));
		//poly.add(null);
		
		
	}
}



/** 
	Exercice 2 :
	
	2/ Il suffit d'ajouter @SuppressWarnings("unchecked") juste avant la méthode
	3/ Cette méthode définissait la taille MAX de notre tableau, on n'en a désormais plus besoin avec cette
		nouvelle implémentation sous forme de liste.



*/
