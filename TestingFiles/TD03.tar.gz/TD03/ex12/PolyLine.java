public class PolyLine {
	
	private Point tab[];

	private int nbPoints;
	private int cpt = 0;

	
	public PolyLine(int nbPoints){
		this.nbPoints = nbPoints;
		tab = new Point[nbPoints];
	}

	public PolyLine(){
		this(10); 	// permet la non duplication de code
	}
	
	public void add( Point p ){
		//if( this.cpt < this.nbPoints ){
		//
		//} else {
		//	System.out.println("Plus de place dans lea PolyLine allouée.");
		//}
		try {
			tab[this.cpt] = p;
			this.cpt += 1;
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Exception : Plus de place dans la PolyLine allouée.");
		}
	}
	
	public int pointCapacity() {
		return this.nbPoints;
	}
	
	public int pointCount() {
		return this.cpt;
	}
	
	public boolean contains( Point p ) {
		
		for (int i=0; i<this.cpt;i++){
			if ( tab[i].isSameAs(p) ) {
				return true;
			}
		}
		return false;
	}
	
	public static void main( String[] args){
		
		PolyLine poly = new PolyLine(3);
		
		Point p1=new Point(1,2);
		Point p2=new Point(2,3);
		Point p3=new Point(3,4);
		Point p4=new Point(4,5);
		Point p5=new Point(5,6);
		
		poly.add(p1);
		poly.add(p2);
		poly.add(p3);
		poly.add(p4);
		poly.add(p5);
		
		System.out.println("Nombre points max : " + poly.pointCapacity());
		System.out.println("Nombre points alloués : " + poly.pointCount());
		
		System.out.println("PolyLine contient p1? : " + poly.contains(p1));
		System.out.println("PolyLine contient p5? : " + poly.contains(p5));
		
		//System.out.println("PolyLine contient p5? : " + poly.contains(null));
		//poly.add(null);
		
		
	}
}


/**

Exercice 1 : 
	
	1/ Non car le nombre de point maximum doit pouvoir varier d'une PolyLine à une autre donc pour 
		toutes les instances de la classe, on doit pouvoir avoir une valeur non fixe.
	
	2/ Dans ce cas l'utilisation d'un espace trop grand pour un tableau n'a pas l'espace suffisant alloué 
		provoque la levée d'une exception ArrayIndexOutOfBoundsException.
	
	4/ Informer l'utilisateur de l'impossibilité sa requête et ignorer l'ajout du Point, en levant une
		exception.
	
	7/ contains : null = renvoie de NullPointerException
	   add : null = renvoie l'interception de l'exception réalisé dans la question 4.
	   
	
	
*/
