import java.util.*;

public class Animal {
	
	private HashMap<String,String> hm;
	
	public Animal() {
		hm = new HashMap<>();
		
		hm.put("Alice", "edith");
		hm.put("Bob", "izard");
		hm.put("June", "gold");
	}
	
	public void getAnimal( String enfant ){
		System.out.println("L'animal préféré de "+enfant+" est : "+hm.get(enfant));
		
		/*switch( enfant ) {
			case "Alice":
				System.out.println("L'animal préféré de "+enfant+" est : edith");
				break;
			case "Bob":
				System.out.println("L'animal préféré de "+enfant+" est : izard");
				break;
			case "June":
				System.out.println("L'animal préféré de "+enfant+" est : gold");
				break;
			default:
				System.out.println("L'animal préféré de "+enfant+" est inconnu.");
				break;
		}*/
	}

	public static void main( String[] args ){
		
		Animal a = new Animal();
		
		if (args.length > 0){
			for(int i=0; i<args.length;i++){
				a.getAnimal(args[i]);
			}
		}
		
	}
}
