package javaavance.td05.ex01;

import java.util.LinkedList;

import javaavance.td05.ex01.NodeListGraph.Pair;


public interface Action<T> {
	T todo(LinkedList<Pair> list);
}
