package javaavance.td05.ex01;

import java.util.HashMap;
import java.util.Iterator;

public class NodeMapGraph implements Graph {
	private final HashMap<Integer, Integer>[] array;
	
	@SuppressWarnings("unchecked")
	public NodeMapGraph(int verticesCount) {
		if (verticesCount <= 0) {
			throw new IllegalArgumentException("Must have positive vertices number.");
		}
		array = (HashMap<Integer, Integer>[]) new HashMap<?,?>[verticesCount];
		for (int i = 0; i < array.length; i++) {
			array[i] = new HashMap<>();
		}
	}

	@Override
	public int verticesCount() {
		return array.length;
	}
	
	private void checkBounds(int src, int dst) {
		if (src < 0 || src >= array.length || dst < 0 || dst >= array.length) {
			throw new IllegalArgumentException("Invalid bounds..");
		}
	}
	
	@Override
	public boolean hasEdge(int src, int dst) {
		if (getWeight(src, dst) == NO_EDGE) {
			return false;
		}
		return true;
	}

	@Override
	public int getWeight(int src, int dst) {
		checkBounds(src, dst);
		HashMap<Integer, Integer> map = array[src];
		Integer weight = map.get(dst);
		if (weight == null) {
			return NO_EDGE;
		}
		return weight;
	}

	@Override
	public void addEdge(int src, int dst, int weight) {
		checkBounds(src, dst);
		if (weight == NO_EDGE) {
			throw new IllegalArgumentException("Can't add edge with no weight.");
		}
		HashMap<Integer, Integer> map = array[src];
		map.put(dst, weight);
	}

	@Override
	public int removeEdge(int src, int dst) {
		checkBounds(src, dst);
		HashMap<Integer, Integer> map = array[src];
		
		Integer value; 
		if ((value = map.remove(dst)) != null) {
			return value;
		}
		
		return NO_EDGE;
	}

	@Override
	public Iterator<Integer> neighbors(int vertex) {
		
		return new Iterator<Integer>() {
			HashMap<Integer, Integer> map = array[vertex];
			Iterator<Integer> index = map.keySet().iterator();
			
			@Override
			public Integer next() {
				return index.next();
			}
			
			@Override
			public boolean hasNext() {
				return index.hasNext();
			}
			
			@Override
			public void remove() {
				index.remove();
			}
		};
	}
	
	
}
