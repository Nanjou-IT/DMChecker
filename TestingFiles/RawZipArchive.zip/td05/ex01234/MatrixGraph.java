package javaavance.td05.ex01;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MatrixGraph implements Graph {
	private final int matrix[];
	final int verticesCount;  // pas de private -> pas de generation d'accesseur inutile
	
	public MatrixGraph(int verticesCount) {
		if (verticesCount <= 0) {
			throw new IllegalArgumentException("Must have positive vertices number.");
		}
		int[] values = new int[verticesCount*verticesCount]; 
		Arrays.fill(values, NO_EDGE);
		this.matrix = values;
		this.verticesCount = verticesCount;
	}

	@Override
	public int verticesCount() {
		return verticesCount;
	}
	
	private void checkEdge(int src, int dst) {
		if (src < 0 || src >= verticesCount) {
			throw new IllegalArgumentException("Source must be positive and < vertices number");
		}
		if (dst < 0 || dst >= verticesCount) {
			throw new IllegalArgumentException("Destination must be positive and < vertices number");
		}
	}

	@Override
	public boolean hasEdge(int src, int dst) {
		checkEdge(src, dst);
		if (matrix[src*verticesCount+dst] != NO_EDGE) {
			return true;
		}
		return false;
	}
	
	@Override
	public int getWeight(int src, int dst) {
		checkEdge(src, dst);
		return matrix[src*verticesCount+dst];
	}

	@Override
	public void addEdge(int src, int dst, int weight) {
		checkEdge(src, dst);
		if (weight == NO_EDGE) {
			throw new IllegalArgumentException("Edge weight is invalid.");
		}
		matrix[src*verticesCount+dst] = weight;
	}

	@Override
	public int removeEdge(int src, int dst) {
		checkEdge(src, dst);
		int edgeWeight = matrix[src*verticesCount+dst];
		matrix[src*verticesCount+dst] = NO_EDGE;
		return edgeWeight;
	}
	
	@Override
	public Iterator<Integer> neighbors(int vertex) {
		if (vertex < 0 || vertex >= verticesCount) {
			throw new IllegalArgumentException("Vertex is invalid..");
		}
		
		return new Iterator<Integer>() {
			private int index = nextEdge(0);
			private int lastIndex = -1;
			
			private int nextEdge(int start) {
				for (int i = start; i < verticesCount; i++) {
					if (hasEdge(vertex, i)) {
						return i;
					}
				}
				return -1;
			}
			
			@Override
			public Integer next() {
				if (index == -1) {
					throw new NoSuchElementException("No next values..");
				}
				int value = index;
				lastIndex = index;
				index = nextEdge(value+1);
				return value;
			}
			
			@Override
			public boolean hasNext() {
				return index != -1;
			}
			
			@Override
			public void remove() {
				if (lastIndex == -1) {
					throw new IllegalStateException("Cannot remove inexistant index.");
				}
				removeEdge(vertex, lastIndex);
				lastIndex = -1;
			}
		};
	}
}
