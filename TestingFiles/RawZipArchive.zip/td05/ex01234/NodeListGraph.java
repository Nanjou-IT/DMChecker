package javaavance.td05.ex01;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;

public class NodeListGraph implements Graph {
	private final LinkedList<Pair>[] array;
	
	@SuppressWarnings("unchecked")
	public NodeListGraph(int verticesCount) {
		if (verticesCount <= 0) {
			throw new IllegalArgumentException("Must have positive vertices number.");
		}
		array = (LinkedList<Pair>[]) new LinkedList<?>[verticesCount];
		for (int i = 0; i < array.length; i++) {
			array[i] = new LinkedList<>();
		}
	}
	
	@Override
	public int verticesCount() {
		return array.length;
	}
	
	private void checkBounds(int src, int dst) {
		if (src < 0 || src >= array.length || dst < 0 || dst >= array.length) {
			throw new IllegalArgumentException("Invalid bounds..");
		}
	}

	@Override
	public boolean hasEdge(int src, int dst) {
		if (getWeight(src, dst) != NO_EDGE) {
			return true;
		}
		return false;
	}

	@Override
	public int getWeight(int src, int dst) {
		checkBounds(src, dst);
		LinkedList<Pair> fromSrc = array[src];
		for (Pair p : fromSrc) {
			if (p.dst == dst) {
				return p.weight;
			}
		}
		return NO_EDGE;
	}

	@Override
	public void addEdge(int src, int dst, int weight) {
		checkBounds(src, dst);
		if (weight == NO_EDGE) {
			throw new IllegalArgumentException("Edge weight can't be the NO_EDGE value.");
		}
		// dst can be over than vertices number.
		Pair p = new Pair(dst, weight);
		LinkedList<Pair> fromSrc = array[src];
		if (!hasEdge(src, dst)) {
			fromSrc.add(p);
		} else {
			for (int i = 0; i < fromSrc.size(); i++) {
				if (fromSrc.get(i).dst == dst) {
					fromSrc.get(i).setWeight(weight);
				}
			}
		}
	}

	@Override
	public int removeEdge(int src, int dst) {
		checkBounds(src, dst);
		
		Iterator<Pair> it = array[src].iterator();
		while (it.hasNext()) {
			Pair p = it.next();
			if (p.dst == dst) {
				int value = p.weight;
				array[src].remove(p);
				return value;
			}
		}
//		
		return NO_EDGE;
	}

	@Override
	public Iterator<Integer> neighbors(int vertex) {
		if (vertex < 0 || vertex >= array.length) {
			throw new IllegalArgumentException("Vertex is invalid..");
		}
		
		return new Iterator<Integer>() {
			private Iterator<Pair> index = array[vertex].iterator();
			
			@Override
			public boolean hasNext() {
				return index.hasNext();
			}

			@Override
			public Integer next() {
				return index.next().dst;
			}
			
			@Override
			public void remove() {
				index.remove();
			}
		};
	}
	
	/**
	 * Data abstracted type of a destination point into the graph.
	 * Note : Two destination points are equals if their destination values
	 * 		  are matching. The weight does not matter.
	 */
	public static class Pair { // static pas de ptr sur la classe englobante
		private final int dst;
		private int weight;
		
		Pair(int dst, int weight) { // package visibility
			this.dst = dst;
			this.weight = weight;
		}
		
		private void setWeight(int weight) {
			this.weight = weight;
		}
		
		@Override
		public boolean equals(Object o) {
			if (!(o instanceof Pair)) {
				return false;
			}
			Pair p = (Pair)o;
			return p.dst==dst;
		}
	}
}
